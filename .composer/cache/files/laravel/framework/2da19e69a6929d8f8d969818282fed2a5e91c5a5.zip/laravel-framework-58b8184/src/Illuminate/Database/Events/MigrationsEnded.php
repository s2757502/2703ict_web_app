<?php

namespace Illuminate\Database\Events;

use Illuminate\Contracts\Database\Events\MigrationEvent as MigrationEventContract;

class MigrationsEnded implements MigrationEventContract
{
    //
}
