<?php $__env->startSection('title'); ?>
  Social Media: Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main role="main" class="container">
    <div class = "row" id = "content">
        <div class="col-md-3">
            <h4>Create User</h4>
            <form method="post" action="<?php echo e(url("create_user_action")); ?>">
            <?php echo e(csrf_field()); ?>

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
                <p><label>Username:</label><br><input type="text" name="username"></p>
                <input type="submit" value="Submit">
            </form>
        </div>
        <div class="col-md-9">
            <h4>Users with Posts</h4>
            <?php if($users_with): ?>
                <?php $__currentLoopData = $users_with; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <div class="postOptions">
                            <a href="<?php echo e(url("edit_user/$user->user_id")); ?>">edit</a> | <a href="<?php echo e(url("delete_user_action/$user->user_id")); ?>">delete</a>
                        </div>
                        <div class="postContents">
                            <img class="postImage" src="<?php echo e(asset($user->picture)); ?>" width="150" alt="user image">
                            <div class="postText">
                                <span class="postUser"><?php echo e($user->username); ?></span><br>
                                <span class="postTitle">
                                    <a href='<?php echo e(url("user_posts/$user->user_id")); ?>'>
                                        <?php echo e($user->number_of_posts); ?>

                                        <?php if($user->number_of_posts == 1): ?>
                                            post
                                        <?php else: ?>
                                            posts
                                        <?php endif; ?>
                                            by this user. Click to view.
                                    </a>
                                </span><br>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            <?php else: ?>
                No users found.
            <?php endif; ?>
            <h4>Users without Posts</h4>
            <?php if($users_without): ?>
                <?php $__currentLoopData = $users_without; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <div class="postOptions">
                            <a href="<?php echo e(url("edit_user/$user->user_id")); ?>">edit</a> | <a href="<?php echo e(url("delete_user_action/$user->user_id")); ?>">delete</a>
                        </div>
                        <div class="postContents">
                            <img class="postImage" src="<?php echo e(asset($user->picture)); ?>" width="150" alt="user image">
                            <div class="postText">
                                <span class="postUser"><?php echo e($user->username); ?></span><br>
                                <span class="postMessage">0 posts by this user.</span><br>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            <?php else: ?>
                No users found.
            <?php endif; ?> 
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/project/resources/views/users.blade.php ENDPATH**/ ?>