
<?php $__env->startSection('title'); ?>
  Social Media: Edit Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main role="main" class="container">
    <div class = "row" id = "content">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <form method="post" action=" <?php echo e(url("edit_post_action")); ?>" style="border-style: solid; text-align:center; padding: 20px;">
                <?php echo e(csrf_field()); ?>

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
                <h4>Edit Post</h4>
                <input type="hidden" name="post_id" value="<?php echo e($post->post_id); ?>">
                <p><label>Username:</label><br><input type="text" name="username" value="<?php echo e($post->username); ?>"></p>
                <p><label>Title:</label><br><textarea type="text" name="title"><?php echo e($post->title); ?></textarea></p>
                <p><label>Message:</label><br><textarea type="text" name="message"><?php echo e($post->message); ?></textarea></p>
                <input type="submit" value="Submit">
            </form>
        </div>
        <div class="col-md-4"></div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/project/resources/views/edit_post.blade.php ENDPATH**/ ?>