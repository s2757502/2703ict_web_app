<?php $__env->startSection('title'); ?>
  Social Media: Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main role="main" class="container">
    <div class = "row" id = "content">
        <div class="col-md-3">
            <h4>Create Comment</h4>
            <form method="post" action="<?php echo e(url("create_comment_action")); ?>">
            <?php echo e(csrf_field()); ?>

            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
            <input type="hidden" name="post_id" value="<?php echo e($post->post_id); ?>">
                <p><label>Username:</label><br><input type="text" name="username"></p>
                <p><label>Message:</label><br><textarea type="text" name="message"></textarea></p>
                <input type="submit" value="Submit">
            </form>
        </div>
        <div class="col-md-9">
            <h4>Post</h4>
            <div class="post">
                <div class="postOptions">
                    <a href="<?php echo e(url("edit_post/$post->post_id")); ?>">edit</a> | <a href="<?php echo e(url("delete_post_action/$post->post_id")); ?>">delete</a>
                </div>
                <div class="postContents">
                    <img class="postImage" src="<?php echo e(asset($post->icon)); ?>" width="150" alt="user image">
                    <div class="postText">
                        <span class="postUser"><?php echo e($post->username); ?></span><br>
                        <span class="postDate">Created: <?php echo e(date('d-m-Y H:i:s', $post->cdate)); ?> <?php if(isset($post->edate)): ?> Last Edited: <?php echo e(date('d-m-Y H:i:s', $post->edate)); ?> <?php endif; ?></span><br>
                        <span class="postTitle"><?php echo e($post->title); ?></span><br>
                        <span class="postMessage"><?php echo e($post->message); ?></span>
                    </div>
                </div>
            </div>
            <?php if($comments): ?>
                <h4>Comments</h4>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <div class="postOptions">
                            <a href="<?php echo e(url("edit_comment/$comment->comment_id")); ?>">edit</a> | <a href="<?php echo e(url("delete_comment_action/$comment->comment_id")); ?>">delete</a>
                        </div>
                        <div class="postContents">
                            <div class="postText">
                                <span class="postUser"><?php echo e($comment->username); ?></span><br>
                                <span class="postDate">Created: <?php echo e(date('d-m-Y H:i:s', $comment->cdate)); ?> <?php if(isset($comment->edate)): ?> Last Edited: <?php echo e(date('d-m-Y H:i:s', $comment->edate)); ?> <?php endif; ?></span><br>
                                <span class="postMessage"><?php echo e($comment->message); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/project/resources/views/post.blade.php ENDPATH**/ ?>