
<?php $__env->startSection('title'); ?>
  Social Media: Edit Comment
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main role="main" class="container">
    <div class = "row" id = "content">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <form method="post" action=" <?php echo e(url("edit_comment_action")); ?>" style="border-style: solid; text-align:center; padding: 20px;">
                <?php echo e(csrf_field()); ?>

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
                <h4>Edit Comment</h4>
                <input type="hidden" name="comment_id" value="<?php echo e($comment->comment_id); ?>">
                <p><label>Username:</label><br><input type="text" name="username" value="<?php echo e($comment->username); ?>"></p>
                <p><label>Message:</label><br><textarea type="text" name="message"><?php echo e($comment->message); ?></textarea></p>
                <input type="submit" value="Submit">
            </form>
        </div>
        <div class="col-md-4"></div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/project/resources/views/edit_comment.blade.php ENDPATH**/ ?>