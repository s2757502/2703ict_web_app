<?php $__env->startSection('title'); ?>
  Social Media: Comments
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main role="main" class="container">
    <div class = "row" id = "content">
        <div class="col-md-4">
            <h4>Create Comment</h4>
            <form method="post" action="<?php echo e(url("create_comment_action")); ?>">
            <?php echo e(csrf_field()); ?>

                <p><label>Username:</label><br><input type="text" name="username"></p>
                <p><label>Message:</label><br><textarea type="text" name="message"></textarea></p>
                <input type="submit" value="Submit">
            </form>
        </div>
        <div class="col-md-8">
            <h4>Posts</h4>
            
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/project/resources/views/post_comments.blade.php ENDPATH**/ ?>