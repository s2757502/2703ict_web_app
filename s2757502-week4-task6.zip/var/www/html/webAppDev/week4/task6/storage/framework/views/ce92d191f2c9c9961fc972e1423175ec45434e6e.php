
<?php $__env->startSection('title'); ?>
  Prime Minister Search
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <h2>Australian Prime Ministers</h2>
  <h3>Query</h3>
  <?php if(isset($error)): ?>
  <p class="alert"><?php echo e($error); ?></p>
  <?php endif; ?>
  <form method="post" action="results">
  <?php echo e(csrf_field()); ?>

    <table>
      <tr><td>Name: </td><td><input type="text" name="name"></td></tr>
      <tr><td>Year: </td><td><input type="text" name="year"></td></tr>
      <tr><td>State: </td><td><input type="text" name="state"></td></tr>
      <tr><td colspan=2><input type="submit" value="Search">
                        <input type="reset" value="Reset"></td></tr>
    <table>
  </form>

  <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task6/resources/views/greetingForm.blade.php ENDPATH**/ ?>