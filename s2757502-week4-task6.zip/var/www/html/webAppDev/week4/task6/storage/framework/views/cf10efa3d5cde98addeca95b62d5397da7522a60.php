<?php $__env->startSection('title'); ?>
  Associative array search results page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <h2>Australian Prime Ministers</h2>

    <?php if(count($pms) == 0): ?> 
      <p>No results found.</p>
    <?php else: ?>
      <h4>Search result for: <u><?php echo e($query); ?></u></h4>
      <table class="bordered">
        <thead>
          <tr><th>No.</th><th>Name</th><th>From</th><th>To</th><th>Duration</th><th>Party</th><th>State</th></tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $pms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr><td><?php echo e($pm['index']); ?></td><td><?php echo e($pm['name']); ?></td><td><?php echo e($pm['from']); ?></td><td><?php echo e($pm['to']); ?></td><td><?php echo e($pm['duration']); ?></td><td><?php echo e($pm['party']); ?></td><td><?php echo e($pm['state']); ?></td></tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <?php endif; ?>
  <p><a href="../public">New search</a></p>
  <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task6/resources/views/results.blade.php ENDPATH**/ ?>