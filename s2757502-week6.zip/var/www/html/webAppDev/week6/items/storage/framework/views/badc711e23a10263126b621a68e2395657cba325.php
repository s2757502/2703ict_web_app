
<?php $__env->startSection('title'); ?>
  Update Item
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form method="post" action=" <?php echo e(url("update_item_action")); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
        <p>
            <label>Summary: </label>
            <input type="text" name="summary" value="<?php echo e($item->summary); ?>">
        </p>
        <p>
            <label>Details:</label>
            <textarea name="details"><?php echo e($item->details); ?></textarea>
        </p>
        <input type="submit" value="Update item">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week6/items/resources/views/items/update_item.blade.php ENDPATH**/ ?>